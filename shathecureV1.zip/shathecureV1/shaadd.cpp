#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <string>
#include <thread>
#include <mutex>
#include <chrono>
#include <atomic>
#include <future>
#include <secp256k1.h>
#include <openssl/sha.h>
#include <openssl/ripemd.h>
#include <unordered_set>
#include <memory>

class KeyProcessor {
private:
    std::unique_ptr<secp256k1_context, decltype(&secp256k1_context_destroy)> ctx;

public:
    KeyProcessor() : ctx(secp256k1_context_create(SECP256K1_CONTEXT_SIGN), &secp256k1_context_destroy) {
        if (!ctx) {
            throw std::runtime_error("Failed to initialize secp256k1 context");
        }
    }

    std::vector<unsigned char> generateCompressedPublicKey(const std::vector<unsigned char>& privateKey) {
        secp256k1_pubkey pubkey;
        if (!secp256k1_ec_pubkey_create(ctx.get(), &pubkey, privateKey.data())) {
            throw std::runtime_error("Failed to create public key");
        }

        unsigned char output[33];
        size_t outputLen = sizeof(output);
        secp256k1_ec_pubkey_serialize(ctx.get(), output, &outputLen, &pubkey, SECP256K1_EC_COMPRESSED);

        return std::vector<unsigned char>(output, output + outputLen);
    }

    std::vector<unsigned char> generateUncompressedPublicKey(const std::vector<unsigned char>& privateKey) {
        secp256k1_pubkey pubkey;
        if (!secp256k1_ec_pubkey_create(ctx.get(), &pubkey, privateKey.data())) {
            throw std::runtime_error("Failed to create public key");
        }

        unsigned char output[65];
        size_t outputLen = sizeof(output);
        secp256k1_ec_pubkey_serialize(ctx.get(), output, &outputLen, &pubkey, SECP256K1_EC_UNCOMPRESSED);

        return std::vector<unsigned char>(output, output + outputLen);
    }

    std::vector<unsigned char> sha256(const std::vector<unsigned char>& input) {
        std::vector<unsigned char> hash(SHA256_DIGEST_LENGTH);
        SHA256(input.data(), input.size(), hash.data());
        return hash;
    }

    std::vector<unsigned char> ripemd160(const std::vector<unsigned char>& input) {
        std::vector<unsigned char> hash(RIPEMD160_DIGEST_LENGTH);
        RIPEMD160(input.data(), input.size(), hash.data());
        return hash;
    }

    std::string toHexString(const std::vector<unsigned char>& input) {
        std::ostringstream oss;
        for (const auto& byte : input) {
            oss << std::hex << std::setw(2) << std::setfill('0') << (int)byte;
        }
        return oss.str();
    }
};

std::atomic<bool> foundMatch(false);
std::atomic<size_t> keysChecked(0);

void processKeys(const std::vector<std::string>& keys, const std::unordered_set<std::string>& targetHashes, const std::string& outputFile) {
    KeyProcessor processor;
    std::ofstream foundOut(outputFile, std::ios::app);
    if (!foundOut.is_open()) {
        throw std::runtime_error("Failed to open output file");
    }

    for (const auto& hexKey : keys) {
        if (foundMatch.load()) return;

        if (hexKey.size() != 64) continue;

        std::vector<unsigned char> privateKey(32);
        for (size_t i = 0; i < 64; i += 2) {
            privateKey[i / 2] = std::stoi(hexKey.substr(i, 2), nullptr, 16);
        }

        auto compressedKey = processor.generateCompressedPublicKey(privateKey);
        auto uncompressedKey = processor.generateUncompressedPublicKey(privateKey);

        auto compressedHash = processor.ripemd160(processor.sha256(compressedKey));
        auto uncompressedHash = processor.ripemd160(processor.sha256(uncompressedKey));

        std::string compressedHashStr = processor.toHexString(compressedHash);
        std::string uncompressedHashStr = processor.toHexString(uncompressedHash);

        keysChecked++;

        if (targetHashes.count(compressedHashStr) || targetHashes.count(uncompressedHashStr)) {
            foundOut << "MATCH FOUND: " << hexKey << " -> "
                     << (targetHashes.count(compressedHashStr) ? compressedHashStr : uncompressedHashStr) << std::endl;
            foundMatch.store(true);
            return;
        }
    }
}

void processKeysFromFile(const std::string& privateKeyFile, const std::string& ripemdFile, size_t numThreads) {
    std::ifstream infile(privateKeyFile);
    if (!infile.is_open()) {
        throw std::runtime_error("Failed to open private key file");
    }

    std::ifstream targetFile(ripemdFile);
    if (!targetFile.is_open()) {
        throw std::runtime_error("Failed to open RIPEMD-160 hashes file");
    }

    std::unordered_set<std::string> targetHashes;
    std::string hash;
    while (targetFile >> hash) {
        targetHashes.insert(hash);
    }

    std::vector<std::string> keys;
    std::string hexKey;
    while (infile >> hexKey) {
        keys.push_back(hexKey);
    }

    size_t keysPerThread = keys.size() / numThreads;
    std::vector<std::future<void>> futures;

    auto startTime = std::chrono::steady_clock::now();

    for (size_t i = 0; i < numThreads; ++i) {
        size_t start = i * keysPerThread;
        size_t end = (i == numThreads - 1) ? keys.size() : start + keysPerThread;
        futures.push_back(std::async(std::launch::async, processKeys, 
                                     std::vector<std::string>(keys.begin() + start, keys.begin() + end), 
                                     targetHashes, "FOUNDSHA.txt"));
    }

    for (auto& future : futures) {
        future.get();
    }

    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() - startTime).count();
    std::cout << "Keys Checked: " << keysChecked.load() << ", Time Elapsed: " << elapsed << "s" << std::endl;
}

int main() {
    try {
        std::string privateKeyFile, ripemdFile;
        std::cout << "Path to Private Keys File: ";
        std::cin >> privateKeyFile;
        std::cout << "Path to RIPEMD-160 Hashes File: ";
        std::cin >> ripemdFile;

        size_t numThreads = std::thread::hardware_concurrency();
        if (numThreads == 0) numThreads = 4;

        processKeysFromFile(privateKeyFile, ripemdFile, numThreads);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }
    return 0;
}
